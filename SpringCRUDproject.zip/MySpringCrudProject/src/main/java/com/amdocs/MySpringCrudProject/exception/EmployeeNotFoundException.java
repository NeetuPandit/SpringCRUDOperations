package com.amdocs.MySpringCrudProject.exception;

public class EmployeeNotFoundException extends RuntimeException {

	public EmployeeNotFoundException() {
		// TODO Auto-generated constructor stub
		
	}

	public EmployeeNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}

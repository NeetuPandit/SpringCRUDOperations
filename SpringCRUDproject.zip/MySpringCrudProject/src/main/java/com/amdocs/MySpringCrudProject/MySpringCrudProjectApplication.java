package com.amdocs.MySpringCrudProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MySpringCrudProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MySpringCrudProjectApplication.class, args);
	}

}

package com.amdocs.MySpringCrudProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringCrudProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
